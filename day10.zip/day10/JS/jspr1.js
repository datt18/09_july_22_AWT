function my(){
    document.getElementById("dom1").style.fontSize ="100px";

}
function hello(){
    document.getElementById("dom2").style.fontFamily = "Impact,Charcoal,sans-serif";
}
function hii(){
    document.getElementById("dom3").style.display="none";

}